import re
import pandas as pd
import netaddr
from bisect import bisect

ips = pd.read_csv("ip2location.csv")

def lookup_region(ip):
    ip_address = re.sub(r'[a-z]', '0' , ip)
    ip_address = int(netaddr.IPAddress(ip_address))
    idx = bisect(ips['low'], ip_address)
    return ips.at[idx-1, 'region']

def address_search(html):
    address = []
    for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>', html):
        lines = []
        for line in re.findall(r'<span class="mailerAddress">([\s\S]+?)</span>', addr_html):
            lines.append(line.strip())
        if ('\n'.join(lines)) !=  "":
            address.append("\n".join(lines))
    return address

class Filing:
    def __init__(self, html):
        self.dates = re.findall(r"19\d{2}-\d{2}-\d{2}|20\d{2}-\d{2}-\d{2}", html)
        sic_number = re.findall(r"SIC\=(\d+)", html)
        if len(sic_number) == 0:
            self.sic = None
        else:
            self.sic = int(sic_number[0])
        self.addresses = address_search(html)

    def state(self):
        states = []
        for address in self.addresses:
            if len(re.findall(r'[A-Z]{2} [0-9]{5}', address)) == 0:
                continue
            else:
                states.append(re.findall(r'([A-Z]{2}) [0-9]{5}', address)[0])
        if len(states) == 0:        
            return None

        return states[0]